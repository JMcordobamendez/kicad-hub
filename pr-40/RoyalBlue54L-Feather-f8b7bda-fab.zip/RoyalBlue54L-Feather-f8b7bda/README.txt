FABRICATION NOTES
=================

Board        RoyalBlue54L-Feather
Revision     f8b7bda
Company      -
Generated    2026-10-30 by kicad-hub from the KiCad project

!! CHECK BEFORE ORDERING
  - Via drill 0.00001 mm is below the project minimum drill 0.2 mm

BOARD
  Size              58.52 mm x 22.96 mm
  Copper layers     8
  Thickness         1.6 mm
  Surface finish    ENIG
  Impedance control no
  Edge plating      no
  Castellated pads  yes

STACKUP
  F.Cu           0.0350 mm
  dielectric 1   0.1000 mm  prepreg  FR4  Er 4.5
  In1.Cu         0.0350 mm
  dielectric 2   0.3000 mm  core  FR4  Er 4.5
  In2.Cu         0.0350 mm
  dielectric 3   0.1000 mm  prepreg  FR4  Er 4.5
  In3.Cu         0.0350 mm
  dielectric 4   0.3000 mm  core  FR4  Er 4.5
  In4.Cu         0.0350 mm
  dielectric 5   0.1000 mm  prepreg  FR4  Er 4.5
  In5.Cu         0.0350 mm
  dielectric 6   0.3000 mm  core  FR4  Er 4.5
  In6.Cu         0.0350 mm
  dielectric 7   0.1000 mm  prepreg  FR4  Er 4.5
  B.Cu           0.0350 mm

SMALLEST FEATURES USED ON THE BOARD
  Track width       0.1 mm
  Via drill         0.00001 mm
  Via diameter      0.35 mm
  Plated pad hole   0.2 mm
  Vias / PTH / NPTH 183 / 86 / 9

DESIGN RULES (project minimums)
  Track width       0.0762 mm
  Clearance         0.0762 mm
  Through drill     0.2 mm
  Hole to hole      0.25 mm

ASSEMBLY
  SMD parts         51
  THT parts         2
  Parts on bottom   1

FILES
  gerber/      Gerber X2 + job file (.gbrjob): layer stack and attributes
  drill/       Excellon, plated and non-plated holes in separate files, drill map (PDF)
  *.d356       IPC-D-356 netlist for electrical test
  assembly/    BOM (CSV, grouped, DNP excluded) and pick & place (CSV, mm, both sides)
  SHA256SUMS.txt  checksums of every file in this package

FAB PROFILE: jlcpcb
  Checked with a second DRC that adds jlcpcb's published capabilities
  (kicad-hub fab-profiles/jlcpcb/rules.kicad_dru); see the DRC report.
  assembly/jlcpcb/  BOM and pick & place in jlcpcb's column layout, when it has one

VARIANTS (same bare board, different assembly)
  default: assembly/
  lite: assembly/lite/  Without the onboard debugger (U5, U6, Y2 and crystal caps not fitted)
